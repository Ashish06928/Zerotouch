﻿namespace AspnetRun.Web.ViewModels.Base
{
    public class BaseViewModel
    {
        public int Id { get; set; }

    }
}
