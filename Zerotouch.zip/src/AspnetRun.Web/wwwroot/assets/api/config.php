<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'qhwSleIMtLeRbqYY2kabwLCc0');
    define('CONSUMER_SECRET', '00WTXq2fxd0W7i3mHqBsT6Bjm81eIYvNFbCcoHfW2bIIvVxDQX');

    // User Access Token
    define('ACCESS_TOKEN', '3750582733-C9SXrSxDNLTWF6QWShAoKZfxqR5xQ0yfNzgQu6X');
    define('ACCESS_SECRET', 'SclQ7mmInfFUqhL0dEQf561g6tkOXLNEzWmei9g1qtePf');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));